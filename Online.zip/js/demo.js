function demo(){
    alert('index.jade 组件独有的js')
}