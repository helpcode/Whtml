function demo(){
    alert(1)
}